
const { google } = require('googleapis');


function _authorize(action) {
    let client_id = action.params.CLIENT_ID;
    let client_secret = action.params.CLIENT_SECRET;
    let redirect_uris = [action.params.REDIRECT_URIS, "http://localhost"];

    const oauth2Client = new google.auth.OAuth2(
        client_id, client_secret, redirect_uris[0]);
    let access_token = action.params.ACCESS_TOKEN;
    let scope = action.params.SCOPES;
    oauth2Client.credentials = {
        access_token: access_token,
        scope: scope,
        refresh_token: action.params.REFRESH_TOKEN
    }
    return google.admin({ version: 'directory_v1', oauth2Client });
}

function _handleParams(param) {
    if (typeof param == 'string')
        return JSON.parse(param);
    else
        return param;
}

function createUser(action) {
    return new Promise((resolve,reject) => {
        const user = {
            name: {
                familyName: action.params.FAMILY_NAME,
                givenName: action.params.GIVEN_NAME
            },
            password: action.params.PASSWORD,
            primaryEmail: action.params.PRIMARY_EMAIL
        }
    
        let service = _authorize(action);
        return service.users.insert({ resource: user },(err,res) => {
            if(err){
                return reject(err)
            }
            if (action.params.GROUPS) {
                let groups = _handleParams(action.params.GROUPS);
                return Promise.all(groups.map(group => _addUserToGroup(service, group, { email: user.primaryEmail }))).then(()=>res);
            }
            return resolve(res);
        });
    })
}

function _addUserToGroup(service, groupKey, user) {
    return new Promise((resolve,reject) => {
        return service.members.insert({ groupKey: groupKey, resource: user },(err,res) => {
            if(err){
                return reject(err)
            }
            resolve()
        });
    })
}

function addUserToGroup(action) {
    return _addUserToGroup(_authorize(action), action.params.GROUP_KEY, {
        email: action.params.PRIMARY_EMAIL
    });
}

createUser({
    params:{
        CLIENT_ID:"707889613268-6qnvc3t0nv4jpva53pbbp55rimlt1u6g.apps.googleusercontent.com",
        CLIENT_SECRET:"tIPR0p2rlpssVOaRt96bARVm",
        REDIRECT_URIS:"urn:ietf:wg:oauth:2.0:oob",
        ACCESS_TOKEN:"ya29.GluTBoUrBwpETPjoN5cZ2jVSWhdPggdXHvkeB5FPwY1ktP5WmQjckvWr-NT84zwXjiSeLyaDnLE5J8nD5XPquEjx_bgVGkBYaYMb8bkH-D2hu2zRbe6zyxMumJLs",
        REFRESH_TOKEN:"1/IKsU7bfT_OZoTKMhTvX8R8blhJglCRxsGO_iNOIUpNWDxbngjd01lczB8hHJpbba",
        SCOPES:"https://www.googleapis.com/auth/admin.directory.group https://www.googleapis.com/auth/admin.directory.user",
        FAMILY_NAME:"GAHNASS",
        GIVEN_NAME:"DAVID",
        PASSWORD:"PLUGINPLUGIN",
        PRIMARY_EMAIL:"tyui@gsuiteplugin.com",
        GROUPS:'["thekahololo@gsuiteplugin.com","kahololo@gsuiteplugin.com"]'
    }
})

// module.exports = {
//     createUser:createUser,
//     addUserToGroup:addUserToGroup
// }


